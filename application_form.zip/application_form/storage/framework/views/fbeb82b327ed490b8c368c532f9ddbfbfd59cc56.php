


                <a href="create.blade.php">Application Form</a>

<?php /**PATH C:\laragon\www\application_form\resources\views/welcome.blade.php ENDPATH**/ ?>