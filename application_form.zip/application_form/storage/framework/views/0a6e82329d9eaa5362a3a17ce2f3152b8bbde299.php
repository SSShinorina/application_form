<a href="create.blade.php">New Application</a>
<table class="table table-bordered">
  <tr>
      <th>ID</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>E-mail Address</th>
      <th>Phone</th>
      <th>Web Site</th>
      <th>Date Of Birth</th>
      <th>Street Address</th>
      <th>Address Line 2</th>
      <th>City</th>
      <th>State</th>
      <th>Postal</th>
      <th>Country</th>
      <th>Gender</th>
      <th>Bio</th>
      <th>Division</th>
      <th>Salary</th>
      <th>Degree</th>
      <th>Year Of Experience</th>
      <th>Designation</th>
      <th>Action</th>

  </tr>
    <?php $__currentLoopData = $allApplication; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($application->id); ?></td>
            <td><?php echo e($application->fname); ?></td>
            <td><?php echo e($application->lname); ?></td>
            <td><?php echo e($application->email); ?></td>
            <td><?php echo e($application->phone); ?></td>
            <td><?php echo e($application->website); ?></td>
            <td><?php echo e($application->dob); ?></td>
            <td><?php echo e($application->street); ?></td>
            <td><?php echo e($application->address); ?></td>
            <td><?php echo e($application->city); ?></td>
            <td><?php echo e($application->state); ?></td>
            <td><?php echo e($application->postal); ?></td>
            <td><?php echo e($application->country); ?></td>
            <td><?php echo e($application->male); ?></td>
            <td><?php echo e($application->bio); ?></td>
            <td><?php echo e($application->division); ?></td>
            <td><?php echo e($application->salary); ?></td>
            <td><?php echo e($application->degree); ?></td>
            <td><?php echo e($application->experience); ?></td>
            <td><?php echo e($application->designation); ?></td>
            <td>
                <a href="<?php echo e(url('',[$application->id,'edit'])); ?>">Edit</a>
                <?php echo e(Form::open([ 'url' => [ $application->id,'delete']])); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                <?php echo e(Form::close()); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($allApplication->links()); ?>

<?php /**PATH C:\laragon\www\application_form\resources\views/view.blade.php ENDPATH**/ ?>