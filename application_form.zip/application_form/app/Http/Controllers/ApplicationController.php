<?php

namespace App\Http\Controllers;
use App\Application;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;



class ApplicationController extends Controller
{
    public function create(){
        return view('create');
    }
    public function view(){
        $data=Application::paginate(25);
        return view('view',['allApplication'=>$data]);
    }
   public function store(Request $request){
       $data=$request->all();
       Application::create($data);
       Session::flash('message','Application Submitted');
       return redirect()->back();


    }
    public function edit($id){
        $data=Application::find($id);
        return view('edit',compact('data'));


    }
    public function update(Request $request,$id){
        $data=$request->all();
        $existingData=Application::find($id);
            $existingData->update($data);
//        $existingData->update($data,['approved' => 1]);
        Session::flash('message','Application Updated successfully');
        return redirect()->back();
//        $email->update(['approved' => 1]);
//        return redirect()->back();
    }

    public function delete($id){

        $data=Application::find($id);
        $data->delete();
        Session::flash('message','Application Deleted');
        return redirect()->back();
    }
}
