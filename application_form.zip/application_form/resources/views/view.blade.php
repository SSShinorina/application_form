<a href="create.blade.php">New Application</a>
<table class="table table-bordered">
  <tr>
      <th>ID</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>E-mail Address</th>
      <th>Phone</th>
      <th>Web Site</th>
      <th>Date Of Birth</th>
      <th>Street Address</th>
      <th>Address Line 2</th>
      <th>City</th>
      <th>State</th>
      <th>Postal</th>
      <th>Country</th>
      <th>Gender</th>
      <th>Bio</th>
      <th>Division</th>
      <th>Salary</th>
      <th>Degree</th>
      <th>Year Of Experience</th>
      <th>Designation</th>
      <th>Action</th>

  </tr>
    @foreach($allApplication as $application)
        <tr>
            <td>{{$application->id}}</td>
            <td>{{$application->fname}}</td>
            <td>{{$application->lname}}</td>
            <td>{{$application->email}}</td>
            <td>{{$application->phone}}</td>
            <td>{{$application->website}}</td>
            <td>{{$application->dob}}</td>
            <td>{{$application->street}}</td>
            <td>{{$application->address}}</td>
            <td>{{$application->city}}</td>
            <td>{{$application->state}}</td>
            <td>{{$application->postal}}</td>
            <td>{{$application->country}}</td>
            <td>{{$application->gender}}</td>
            <td>{{$application->bio}}</td>
            <td>{{$application->division}}</td>
            <td>{{$application->salary}}</td>
            <td>{{$application->degree}}</td>
            <td>{{$application->experience}}</td>
            <td>{{$application->designation}}</td>
            <td>
                <a href="{{url('',[$application->id,'edit'])}}">Edit</a>
                {{ Form::open([ 'url' => [ $application->id,'delete']]) }}
                {{ Form::submit('Delete', ['class' => 'btn btn-danger']) }}
                {{ Form::close() }}
            </td>
        </tr>
        @endforeach
</table>
{{$allApplication->links()}}
