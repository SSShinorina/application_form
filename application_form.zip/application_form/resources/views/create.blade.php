<a href="view.blade.php">All Application</a>
 @if(Session::has('message'))
     <h2>{{Session::get('message')}}</h2>
 @endif
{!! Form::open(['url' => 'store']) !!}
<?php
echo Form::label('fname', 'First Name:');
echo Form::text('fname',null,['placeholder'=>'xyz']);?>

<br>
<?php
echo Form::label('lname', 'Last Name:');
echo Form::text('lname',null,['placeholder'=>'abc']);?>
<br>
<?php
echo Form::label('email', 'E-Mail Address:');
echo Form::email('email',null,['placeholder'=>'email@email.com']);?>
<br>
<?php
echo Form::label('phone', 'Phone:');
echo Form::text('phone',null,['placeholder'=>'xxxxxxxxxxx']);?>
<br>
<?php
echo Form::label('website', 'Web Site:');
echo Form::text('website',null,['placeholder'=>'https://']);?>
<br>
<?php
echo Form::label('dob', 'Date of Birth:');
echo Form::date('dob',null,['placeholder'=>'MM-DD-YYYY']);
?>
<br>
<?php
echo Form::label('street', 'Street Address:');
echo Form::text('street',null,['placeholder'=>'']);?>
<br><?php
echo Form::label('address', 'Address Line 2:');
echo Form::text('address',null,['placeholder'=>'']);?>
<br><?php
echo Form::label('city', 'City:');
echo Form::text('city',null,['placeholder'=>'']);?>
<br><?php
echo Form::label('state', 'State/Province/Region:');
echo Form::text('state',null,['placeholder'=>'']);?>
<br><?php
echo Form::label('postal', 'Postal/Zip Code:');
echo Form::text('postal',null,['placeholder'=>'']);?>
<br><?php
echo Form::label('country', 'Country:');
echo Form::select('country', ['B' => 'Bangladesh', 'I' => 'India',
    'P'=>'Pakistan', 'A'=>'America']);?>
<br><?php
echo Form::label('gender', 'Gender:');
echo Form::select('gender', ['M' => 'Male', 'F' => 'Female']);?>
<br><?php
echo Form::label('bio', 'Bio:');
echo Form::textarea('bio',null,['placeholder'=>'']);?>
<br><?php
echo Form::label('division', 'Division:');
echo Form::select('division', ['H' => 'HR', 'I' => 'IT',
    'M'=>'Marketing', 'O'=>'Other']);?>;?>
<br><?php
echo Form::label('salary', 'Expected Salary:');
echo Form::text('salary',null,['placeholder'=>'']);?>
<br><?php
echo Form::label('degree', 'Latest Degree:');
echo Form::select('degree', ['B' => 'Bachelor', 'M' => 'Maters',
    'H'=>'H.S.C', 'S'=>'S.S.C']);?>
<br><?php
echo Form::label('experience', 'Your(s) Experience:');
echo Form::number('experience',null,['placeholder'=>'in year']);?>
<br><?php
echo Form::label('designation', 'Name of Current Designation:');
echo Form::text('designation',null,['placeholder'=>'']);?><br>
<?php
echo Form::label('cv', 'Upload CV:');?>
<?php
echo Form::file('Choose File');?>
<br>
<?php
echo Form::submit('Save');?>

{!! Form::close() !!}

